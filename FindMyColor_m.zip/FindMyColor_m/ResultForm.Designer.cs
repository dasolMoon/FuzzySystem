﻿namespace FindMyColor_m
{
    partial class ResultForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResultForm));
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelR = new System.Windows.Forms.Label();
            this.labelG = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelC = new System.Windows.Forms.Label();
            this.labelY = new System.Windows.Forms.Label();
            this.labelM = new System.Windows.Forms.Label();
            this.labelK = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelHex = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelHu = new System.Windows.Forms.Label();
            this.labelV = new System.Windows.Forms.Label();
            this.labelSa = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelTemp = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelDeep = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxPeople = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picSeason = new System.Windows.Forms.PictureBox();
            this.labelLight = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelseason = new System.Windows.Forms.Label();
            this.picLight = new System.Windows.Forms.PictureBox();
            this.picTemp = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.labelL = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPeople)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSeason)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTemp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(291, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "<< 나와 어울리는 색 목록 >>";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(317, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "나의 피부색";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(57, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "대표연예인";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelName.Location = new System.Drawing.Point(153, 178);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(57, 19);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "문근영";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(411, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 75);
            this.label2.TabIndex = 3;
            this.label2.Text = "R : \r\n\r\nG :\r\n\r\nB :";
            // 
            // labelR
            // 
            this.labelR.AutoSize = true;
            this.labelR.BackColor = System.Drawing.Color.Transparent;
            this.labelR.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelR.Location = new System.Drawing.Point(441, 47);
            this.labelR.Name = "labelR";
            this.labelR.Size = new System.Drawing.Size(31, 15);
            this.labelR.TabIndex = 3;
            this.labelR.Text = "255";
            // 
            // labelG
            // 
            this.labelG.AutoSize = true;
            this.labelG.BackColor = System.Drawing.Color.Transparent;
            this.labelG.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelG.Location = new System.Drawing.Point(441, 76);
            this.labelG.Name = "labelG";
            this.labelG.Size = new System.Drawing.Size(31, 15);
            this.labelG.TabIndex = 3;
            this.labelG.Text = "255";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.BackColor = System.Drawing.Color.Transparent;
            this.labelB.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelB.Location = new System.Drawing.Point(441, 106);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(31, 15);
            this.labelB.TabIndex = 3;
            this.labelB.Text = "255";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(487, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 105);
            this.label7.TabIndex = 3;
            this.label7.Text = "C :\r\n\r\nM :\r\n\r\nY :\r\n\r\nK :";
            // 
            // labelC
            // 
            this.labelC.AutoSize = true;
            this.labelC.BackColor = System.Drawing.Color.Transparent;
            this.labelC.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelC.Location = new System.Drawing.Point(519, 47);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(48, 15);
            this.labelC.TabIndex = 3;
            this.labelC.Text = "100 %";
            // 
            // labelY
            // 
            this.labelY.AutoSize = true;
            this.labelY.BackColor = System.Drawing.Color.Transparent;
            this.labelY.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelY.Location = new System.Drawing.Point(519, 106);
            this.labelY.Name = "labelY";
            this.labelY.Size = new System.Drawing.Size(48, 15);
            this.labelY.TabIndex = 3;
            this.labelY.Text = "100 %";
            // 
            // labelM
            // 
            this.labelM.AutoSize = true;
            this.labelM.BackColor = System.Drawing.Color.Transparent;
            this.labelM.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelM.Location = new System.Drawing.Point(518, 76);
            this.labelM.Name = "labelM";
            this.labelM.Size = new System.Drawing.Size(48, 15);
            this.labelM.TabIndex = 3;
            this.labelM.Text = "100 %";
            // 
            // labelK
            // 
            this.labelK.AutoSize = true;
            this.labelK.BackColor = System.Drawing.Color.Transparent;
            this.labelK.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelK.Location = new System.Drawing.Point(518, 136);
            this.labelK.Name = "labelK";
            this.labelK.Size = new System.Drawing.Size(48, 15);
            this.labelK.TabIndex = 3;
            this.labelK.Text = "100 %";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(322, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 15);
            this.label9.TabIndex = 3;
            this.label9.Text = "HEX : ";
            // 
            // labelHex
            // 
            this.labelHex.AutoSize = true;
            this.labelHex.BackColor = System.Drawing.Color.Transparent;
            this.labelHex.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelHex.Location = new System.Drawing.Point(371, 136);
            this.labelHex.Name = "labelHex";
            this.labelHex.Size = new System.Drawing.Size(46, 15);
            this.labelHex.TabIndex = 3;
            this.labelHex.Text = "#ffffff";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(585, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 105);
            this.label10.TabIndex = 3;
            this.label10.Text = "H :\r\n\r\nS :\r\n\r\nV :\r\n\r\nL :";
            // 
            // labelHu
            // 
            this.labelHu.AutoSize = true;
            this.labelHu.BackColor = System.Drawing.Color.Transparent;
            this.labelHu.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelHu.Location = new System.Drawing.Point(619, 46);
            this.labelHu.Name = "labelHu";
            this.labelHu.Size = new System.Drawing.Size(41, 15);
            this.labelHu.TabIndex = 3;
            this.labelHu.Text = "100 º";
            // 
            // labelV
            // 
            this.labelV.AutoSize = true;
            this.labelV.BackColor = System.Drawing.Color.Transparent;
            this.labelV.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelV.Location = new System.Drawing.Point(619, 105);
            this.labelV.Name = "labelV";
            this.labelV.Size = new System.Drawing.Size(48, 15);
            this.labelV.TabIndex = 3;
            this.labelV.Text = "100 %";
            // 
            // labelSa
            // 
            this.labelSa.AutoSize = true;
            this.labelSa.BackColor = System.Drawing.Color.Transparent;
            this.labelSa.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelSa.Location = new System.Drawing.Point(618, 75);
            this.labelSa.Name = "labelSa";
            this.labelSa.Size = new System.Drawing.Size(48, 15);
            this.labelSa.TabIndex = 3;
            this.labelSa.Text = "100 %";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(750, 178);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 14);
            this.label12.TabIndex = 2;
            this.label12.Text = "입니다";
            // 
            // labelTemp
            // 
            this.labelTemp.AutoSize = true;
            this.labelTemp.BackColor = System.Drawing.Color.Transparent;
            this.labelTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelTemp.Location = new System.Drawing.Point(471, 168);
            this.labelTemp.Name = "labelTemp";
            this.labelTemp.Size = new System.Drawing.Size(55, 24);
            this.labelTemp.TabIndex = 2;
            this.labelTemp.Text = "어떤톤";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("G마켓 산스 TTF Medium", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(318, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 15);
            this.label11.TabIndex = 3;
            this.label11.Text = "Deep :";
            // 
            // labelDeep
            // 
            this.labelDeep.AutoSize = true;
            this.labelDeep.BackColor = System.Drawing.Color.Transparent;
            this.labelDeep.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelDeep.Location = new System.Drawing.Point(382, 24);
            this.labelDeep.Name = "labelDeep";
            this.labelDeep.Size = new System.Drawing.Size(22, 15);
            this.labelDeep.TabIndex = 3;
            this.labelDeep.Text = "10";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FindMyColor_m.Properties.Resources.겨울쿨딥;
            this.pictureBox2.Location = new System.Drawing.Point(293, 218);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(500, 281);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBoxPeople
            // 
            this.pictureBoxPeople.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxPeople.Image = global::FindMyColor_m.Properties.Resources.문근영;
            this.pictureBoxPeople.Location = new System.Drawing.Point(36, 201);
            this.pictureBoxPeople.Name = "pictureBoxPeople";
            this.pictureBoxPeople.Size = new System.Drawing.Size(232, 307);
            this.pictureBoxPeople.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPeople.TabIndex = 0;
            this.pictureBoxPeople.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(326, 61);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // picSeason
            // 
            this.picSeason.BackColor = System.Drawing.Color.Transparent;
            this.picSeason.Image = global::FindMyColor_m.Properties.Resources.겨울;
            this.picSeason.Location = new System.Drawing.Point(23, 13);
            this.picSeason.Name = "picSeason";
            this.picSeason.Size = new System.Drawing.Size(137, 89);
            this.picSeason.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSeason.TabIndex = 5;
            this.picSeason.TabStop = false;
            // 
            // labelLight
            // 
            this.labelLight.AutoSize = true;
            this.labelLight.BackColor = System.Drawing.Color.Transparent;
            this.labelLight.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelLight.Location = new System.Drawing.Point(596, 168);
            this.labelLight.Name = "labelLight";
            this.labelLight.Size = new System.Drawing.Size(55, 24);
            this.labelLight.TabIndex = 2;
            this.labelLight.Text = "어떤톤";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(280, 178);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "당신은 ";
            // 
            // labelseason
            // 
            this.labelseason.AutoSize = true;
            this.labelseason.BackColor = System.Drawing.Color.Transparent;
            this.labelseason.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelseason.Location = new System.Drawing.Point(349, 168);
            this.labelseason.Name = "labelseason";
            this.labelseason.Size = new System.Drawing.Size(40, 24);
            this.labelseason.TabIndex = 2;
            this.labelseason.Text = "아무";
            // 
            // picLight
            // 
            this.picLight.BackColor = System.Drawing.Color.Transparent;
            this.picLight.Image = global::FindMyColor_m.Properties.Resources.딥;
            this.picLight.Location = new System.Drawing.Point(23, 108);
            this.picLight.Name = "picLight";
            this.picLight.Size = new System.Drawing.Size(176, 59);
            this.picLight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLight.TabIndex = 5;
            this.picLight.TabStop = false;
            // 
            // picTemp
            // 
            this.picTemp.BackColor = System.Drawing.Color.Transparent;
            this.picTemp.Image = global::FindMyColor_m.Properties.Resources.쿨;
            this.picTemp.Location = new System.Drawing.Point(205, 13);
            this.picTemp.Name = "picTemp";
            this.picTemp.Size = new System.Drawing.Size(63, 89);
            this.picTemp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTemp.TabIndex = 5;
            this.picTemp.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::FindMyColor_m.Properties.Resources.닫기;
            this.pictureBox3.Location = new System.Drawing.Point(739, 28);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(54, 49);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::FindMyColor_m.Properties.Resources.저장;
            this.pictureBox4.Location = new System.Drawing.Point(739, 95);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(54, 54);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // labelL
            // 
            this.labelL.AutoSize = true;
            this.labelL.BackColor = System.Drawing.Color.Transparent;
            this.labelL.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelL.Location = new System.Drawing.Point(619, 134);
            this.labelL.Name = "labelL";
            this.labelL.Size = new System.Drawing.Size(48, 15);
            this.labelL.TabIndex = 3;
            this.labelL.Text = "100 %";
            // 
            // ResultForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(61)))), ((int)(((byte)(78)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(828, 529);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.picTemp);
            this.Controls.Add(this.picLight);
            this.Controls.Add(this.picSeason);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.labelG);
            this.Controls.Add(this.labelSa);
            this.Controls.Add(this.labelM);
            this.Controls.Add(this.labelK);
            this.Controls.Add(this.labelHex);
            this.Controls.Add(this.labelL);
            this.Controls.Add(this.labelV);
            this.Controls.Add(this.labelY);
            this.Controls.Add(this.labelHu);
            this.Controls.Add(this.labelC);
            this.Controls.Add(this.labelDeep);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelR);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelLight);
            this.Controls.Add(this.labelTemp);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.labelseason);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBoxPeople);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ResultForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ResultForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ResultForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPeople)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSeason)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTemp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBoxPeople;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelR;
        private System.Windows.Forms.Label labelG;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.Label labelY;
        private System.Windows.Forms.Label labelM;
        private System.Windows.Forms.Label labelK;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelHex;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelHu;
        private System.Windows.Forms.Label labelV;
        private System.Windows.Forms.Label labelSa;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelTemp;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelDeep;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox picSeason;
        private System.Windows.Forms.Label labelLight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelseason;
        private System.Windows.Forms.PictureBox picLight;
        private System.Windows.Forms.PictureBox picTemp;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label labelL;
    }
}